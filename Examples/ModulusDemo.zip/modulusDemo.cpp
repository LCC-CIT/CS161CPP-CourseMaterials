#include <iostream>
using namespace std;

/*
Pizza is on sale for $1.75 a slice.
You have a 5-dollar bill and want to get as
many slices as you can afford. Write a program
that calculates the number of slices you can buy
and the amount change you will get back. Use the
modulus operator for calculating the change.
*/

int main()
{
    // use whole number valuse for PRICE and CASH so we can do integer division
    // and use the modulus operator
    const short CASH = 500;     // your cash in cents
    const short PRICE = 175;    // price per slice in cents

    // calculate the number of slices of pizza you can afford
    float change = (CASH % PRICE) / 100.0;

    // calculate the number of slices and display the change
    cout << "Slices: " << CASH / PRICE << "\nChange: " << change << endl;

    return 0;
}
